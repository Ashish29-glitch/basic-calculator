const PI = Math.PI;
const E = Math.E;

function toRadians(degrees: number): number {
  return degrees * (Math.PI / 180);
}

function safeEval(expression: string): number {
  try {
    // Whitelist of allowed characters
    if (!/^[0-9+\-*/().√^πe\s]*$/.test(expression)) {
      throw new Error('Invalid characters in expression');
    }
    
    const result = new Function(`return ${expression}`)();
    if (typeof result !== 'number' || !isFinite(result)) {
      throw new Error('Invalid result');
    }
    return result;
  } catch (error) {
    throw new Error('Invalid expression');
  }
}

export function evaluate(expression: string): number {
  try {
    // Remove all spaces
    expression = expression.replace(/\s+/g, '');
    
    // Replace mathematical constants
    expression = expression.replace(/π/g, PI.toString());
    expression = expression.replace(/e/g, E.toString());
    
    // Replace operators
    expression = expression.replace(/×/g, '*');
    expression = expression.replace(/÷/g, '/');
    
    // Handle scientific functions
    while (expression.includes('sin(') || 
           expression.includes('cos(') || 
           expression.includes('tan(') || 
           expression.includes('√(') || 
           expression.includes('log(')) {
      
      expression = expression.replace(/sin\((.*?)\)/g, (match, num) => {
        const value = evaluate(num);
        return Math.sin(toRadians(value)).toString();
      });
      
      expression = expression.replace(/cos\((.*?)\)/g, (match, num) => {
        const value = evaluate(num);
        return Math.cos(toRadians(value)).toString();
      });
      
      expression = expression.replace(/tan\((.*?)\)/g, (match, num) => {
        const value = evaluate(num);
        return Math.tan(toRadians(value)).toString();
      });
      
      expression = expression.replace(/√\((.*?)\)/g, (match, num) => {
        const value = evaluate(num);
        if (value < 0) throw new Error('Cannot calculate square root of negative number');
        return Math.sqrt(value).toString();
      });
      
      expression = expression.replace(/log\((.*?)\)/g, (match, num) => {
        const value = evaluate(num);
        if (value <= 0) throw new Error('Cannot calculate logarithm of non-positive number');
        return Math.log10(value).toString();
      });
    }
    
    // Handle power operator
    while (expression.includes('^')) {
      expression = expression.replace(/(-?\d*\.?\d+)\^(-?\d*\.?\d+)/g, (match, base, exp) => {
        return Math.pow(parseFloat(base), parseFloat(exp)).toString();
      });
    }

    const result = safeEval(expression);
    return Number(result.toFixed(8));
  } catch (error) {
    throw new Error('Invalid expression');
  }
}