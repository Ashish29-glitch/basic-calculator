import { Product } from '../types';

const categories = [
  'electronics',
  'clothing',
  'footwear',
  'books',
  'home',
  'beauty',
  'sports',
  'toys'
];

const electronics = [
  ['Smartphone', 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=500', 15999],
  ['Laptop', 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=500', 49999],
  ['Headphones', 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=500', 2999],
  ['Smartwatch', 'https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=500', 3999],
  ['Camera', 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=500', 29999]
];

const clothing = [
  ['T-Shirt', 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=500', 599],
  ['Jeans', 'https://images.unsplash.com/photo-1542272454315-4c01d7abdf4a?w=500', 1299],
  ['Jacket', 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=500', 2499],
  ['Dress', 'https://images.unsplash.com/photo-1496747611176-843222e1e57c?w=500', 1999],
  ['Shirt', 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=500', 899]
];

const generateProduct = (id: number): Product => {
  const categoryIndex = id % categories.length;
  const category = categories[categoryIndex];
  
  let items;
  switch(category) {
    case 'electronics':
      items = electronics;
      break;
    case 'clothing':
      items = clothing;
      break;
    default:
      items = electronics; // fallback to electronics
  }
  
  const itemIndex = Math.floor(Math.random() * items.length);
  const [title, image, basePrice] = items[itemIndex];
  
  // Add variety to prices
  const priceVariation = 0.2; // 20% variation
  const price = Math.round(basePrice * (1 + (Math.random() - 0.5) * priceVariation));
  
  // Generate realistic rating
  const rating = 3.5 + Math.random() * 1.5;
  const count = 50 + Math.floor(Math.random() * 200);

  return {
    id,
    title: `${title} ${id}`,
    price,
    description: `High-quality ${title.toLowerCase()} for everyday use`,
    category,
    image,
    rating: {
      rate: Number(rating.toFixed(1)),
      count
    }
  };
};

export const generateSampleProducts = (count: number): Product[] => {
  return Array.from({ length: count }, (_, i) => generateProduct(i + 1));
};