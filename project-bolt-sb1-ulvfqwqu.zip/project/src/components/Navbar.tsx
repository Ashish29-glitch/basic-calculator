import React from 'react';
import { Search, ShoppingCart, User } from 'lucide-react';

export default function Navbar() {
  return (
    <nav className="bg-blue-600 text-white py-4 px-6 fixed w-full top-0 z-50">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center space-x-8">
          <h1 className="text-2xl font-bold">ShopKart</h1>
          
          <div className="relative hidden md:block">
            <input
              type="text"
              placeholder="Search for products, brands and more"
              className="w-[400px] px-4 py-2 rounded-lg text-gray-800 focus:outline-none"
            />
            <Search className="absolute right-3 top-2.5 text-gray-500" size={20} />
          </div>
        </div>

        <div className="flex items-center space-x-6">
          <button className="flex items-center space-x-1">
            <User size={20} />
            <span className="hidden md:inline">Login</span>
          </button>
          
          <button className="flex items-center space-x-1">
            <ShoppingCart size={20} />
            <span className="hidden md:inline">Cart</span>
          </button>
        </div>
      </div>
    </nav>
  );
}