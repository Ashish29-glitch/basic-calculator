import React from 'react';
import { Star, ShoppingCart } from 'lucide-react';
import type { Product } from '../types';

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
}

export default function ProductCard({ product, onAddToCart }: ProductCardProps) {
  return (
    <div className="bg-white p-4 rounded-lg shadow-md hover:shadow-lg transition-shadow">
      <div className="relative pb-[100%]">
        <img
          src={product.image}
          alt={product.title}
          className="absolute inset-0 w-full h-full object-contain"
        />
      </div>
      
      <div className="mt-4">
        <h3 className="font-medium text-gray-800 truncate">{product.title}</h3>
        
        <div className="flex items-center mt-2">
          <div className="flex items-center bg-green-600 text-white px-2 py-0.5 rounded text-sm">
            <span>{product.rating.rate}</span>
            <Star size={14} className="ml-1" fill="white" />
          </div>
          <span className="text-gray-500 text-sm ml-2">({product.rating.count})</span>
        </div>

        <div className="mt-2">
          <span className="text-xl font-bold">₹{product.price}</span>
        </div>

        <button
          onClick={() => onAddToCart(product)}
          className="w-full mt-4 bg-blue-600 text-white py-2 rounded-lg flex items-center justify-center space-x-2 hover:bg-blue-700 transition-colors"
        >
          <ShoppingCart size={20} />
          <span>Add to Cart</span>
        </button>
      </div>
    </div>
  );
}