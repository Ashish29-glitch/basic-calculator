import React from 'react';

interface CategoryFilterProps {
  categories: string[];
  selectedCategory: string;
  onSelectCategory: (category: string) => void;
}

export default function CategoryFilter({
  categories,
  selectedCategory,
  onSelectCategory,
}: CategoryFilterProps) {
  return (
    <div className="bg-white p-4 rounded-lg shadow-md">
      <h2 className="text-lg font-semibold mb-4">Categories</h2>
      <div className="space-y-2">
        <button
          className={`w-full text-left px-3 py-2 rounded ${
            selectedCategory === 'all'
              ? 'bg-blue-600 text-white'
              : 'hover:bg-gray-100'
          }`}
          onClick={() => onSelectCategory('all')}
        >
          All Products
        </button>
        {categories.map((category) => (
          <button
            key={category}
            className={`w-full text-left px-3 py-2 rounded ${
              selectedCategory === category
                ? 'bg-blue-600 text-white'
                : 'hover:bg-gray-100'
            }`}
            onClick={() => onSelectCategory(category)}
          >
            {category.charAt(0).toUpperCase() + category.slice(1)}
          </button>
        ))}
      </div>
    </div>
  );
}