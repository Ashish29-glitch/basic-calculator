import React from 'react';

interface KeypadProps {
  onInput: (value: string) => void;
}

interface ButtonProps {
  value: string;
  onClick: () => void;
  className?: string;
}

const Button = ({ value, onClick, className = '' }: ButtonProps) => (
  <button
    onClick={onClick}
    className={`p-3 rounded-lg text-white font-medium text-lg transition-colors
      ${className || 'bg-gray-700 hover:bg-gray-600'}`}
  >
    {value}
  </button>
);

export default function Keypad({ onInput }: KeypadProps) {
  const buttons = [
    ['sin', 'cos', 'tan', 'C'],
    ['7', '8', '9', '÷'],
    ['4', '5', '6', '×'],
    ['1', '2', '3', '-'],
    ['0', '.', '=', '+'],
    ['(', ')', '←', '^'],
    ['π', 'e', '√', 'log']
  ];

  return (
    <div className="grid grid-cols-4 gap-2">
      {buttons.map((row, i) =>
        row.map((btn, j) => (
          <Button
            key={`${i}-${j}`}
            value={btn}
            onClick={() => onInput(btn)}
            className={
              btn === '=' 
                ? 'bg-blue-600 hover:bg-blue-500'
                : btn === 'C'
                ? 'bg-red-600 hover:bg-red-500'
                : ['sin', 'cos', 'tan', '÷', '×', '-', '+', '^', '√', 'log'].includes(btn)
                ? 'bg-gray-600 hover:bg-gray-500'
                : undefined
            }
          />
        ))
      )}
    </div>
  );
}