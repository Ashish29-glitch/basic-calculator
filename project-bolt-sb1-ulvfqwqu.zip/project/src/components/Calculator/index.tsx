import React, { useState } from 'react';
import Display from './Display';
import Keypad from './Keypad';
import { evaluate } from '../../utils/calculator';

export default function Calculator() {
  const [display, setDisplay] = useState('0');
  const [expression, setExpression] = useState('');
  const [showingResult, setShowingResult] = useState(false);

  const handleInput = (value: string) => {
    if (showingResult && !'+-×÷^'.includes(value)) {
      setExpression('');
      setDisplay('0');
      setShowingResult(false);
    }

    switch (value) {
      case 'C':
        setDisplay('0');
        setExpression('');
        setShowingResult(false);
        break;
        
      case '=':
        try {
          if (!expression) return;
          const result = evaluate(expression);
          setDisplay(result.toString());
          setExpression(result.toString());
          setShowingResult(true);
        } catch (error) {
          setDisplay('Error');
          setShowingResult(true);
        }
        break;
        
      case '←':
        if (display.length > 1) {
          const newDisplay = display.slice(0, -1);
          setDisplay(newDisplay);
          setExpression(newDisplay);
        } else {
          setDisplay('0');
          setExpression('');
        }
        break;
        
      case 'sin':
      case 'cos':
      case 'tan':
      case 'log':
      case '√':
        const newFunc = `${value}(${display === '0' ? '' : display})`;
        setDisplay(newFunc);
        setExpression(newFunc);
        break;
        
      default:
        const newDisplay = display === '0' && value !== '.' ? value : display + value;
        setDisplay(newDisplay);
        setExpression(newDisplay);
    }
  };

  return (
    <div className="bg-gray-800 p-6 rounded-2xl shadow-2xl w-full max-w-sm">
      <Display value={display} expression={expression} />
      <Keypad onInput={handleInput} />
    </div>
  );
}