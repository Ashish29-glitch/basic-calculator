import React from 'react';

interface DisplayProps {
  value: string;
  expression: string;
}

export default function Display({ value, expression }: DisplayProps) {
  return (
    <div className="bg-gray-900 p-4 rounded-xl mb-4">
      <div className="text-gray-400 text-right text-sm h-6 overflow-hidden">
        {expression}
      </div>
      <div className="text-white text-right text-3xl font-semibold overflow-hidden">
        {value}
      </div>
    </div>
  );
}